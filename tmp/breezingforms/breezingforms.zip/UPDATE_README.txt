In order to update the component properly, please just install the component, without previous uninstall, otherwise your existing BreezingForms menu items will get lost.

Important: you need at least version 1.7.5 build 759 OR 1.7.3 backport 4 in order to update to 1.8.x!

IMPORTANT: Like for most major extensions, your php installation must allow file uploads higher than the 2MB limit.

For the main BreezingForms component, you need at least a 3MB upload limit.
Please check your php.ini settings or ask your hosting company to raise this limit if it is too low.
