EXTENSION
=============
JOOMLA 1.5 USERS: Joomla! 1.5 is no longer supported. Please use BF version 1.8.4 as it is the last compatible version.

Please install the main component and addons if required (module, content plugins) in the Joomla! Extension Manager. Enable the plugins manually if you need them.

SAMPLE FORMS
=============
If you would like to install the sample forms, then please go to 

BreezingForms => Configuration => Package Installer

and upload one of the XML files. Each XML file contains multiple forms that you can use to start right away.

NATIVE BREEZINGFORMS THEMES
=============
To install themes for the quickmode, simply login to your site using your FTP client
and upload each desired folder to /media/breezingforms/themes/

The theme(s) will then be accessible in the QuickMode editor.
